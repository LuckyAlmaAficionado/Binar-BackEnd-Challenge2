package module;

import java.util.List;

public interface ModuleWritter {
    void writterTxtAndCsv(String path, List<String> data) ;
}
