package module;

import java.util.List;

public interface ModuleRead {
    List<String> readerCsv(String path, int opsi);
}
